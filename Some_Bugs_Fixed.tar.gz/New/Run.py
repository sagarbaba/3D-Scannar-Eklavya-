import Main

Main.Main()
